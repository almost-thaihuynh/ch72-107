import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <p>&copy; 2026 My Online Store. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;